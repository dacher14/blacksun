﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlackSun.Uslugi
{
    public class spisok
    {
        public string id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public bool favorites { get; set; }
        public string foto { get; set; }
    }
}
